package rectangle;

import java.util.Scanner;

public class RectangleWithLenAndBre {
		int length , breadth,area,perimeter;
		void input() {
			Scanner e = new Scanner(System.in);
			System.out.println("Enter the rectangle length value--");
			length = e.nextInt();
			System.out.println("Enter the rectangle breadth value--");
		    breadth = e.nextInt();
		}
		
		void calculate() {
			area =length*breadth;
			perimeter = 2*(length+breadth);
		}
        
		void display() {
			System.out.println("area of rectangle--"+area);
			System.out.println("perimeter of rectangle--"+perimeter);
			
		}
	

		public static void main(String[] args) {
			RectangleWithLenAndBre hu = new RectangleWithLenAndBre();
			 hu.input();
			 hu.calculate();
			 hu.display();
			 
		 
		
		
		}

}
