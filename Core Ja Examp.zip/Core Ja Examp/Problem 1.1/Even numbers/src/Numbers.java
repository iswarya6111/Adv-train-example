import java.util.Scanner;

public class Numbers {
	
	

	public static void main(String[] args) {
		int n=0,i=0;
		Scanner d = new Scanner(System.in);
		System.out.println("Enter the value of even numbers n --" );
		n = d.nextInt();
		for(i=0;i<n; i++) {
			if(i%2==0) {
				System.out.println(i+ "");
				
			}
		
		System.out.println();
		}
		
		
		}

	}


