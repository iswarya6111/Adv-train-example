package com.book;

import java.util.Scanner;

public class TestBook {

		
	public static void main(String[] args) {
		 Scanner b = new Scanner (System.in);
		 System.out.println("Enter the BOOK TITLE--");
	      String BookTitle = b.nextLine();
	      System.out.println("Enter the BOOK PRICE--");
	      int BookPrice = b.nextInt();
	      b.nextLine();
	      
	     Book n = new Book();
	      n.setBooktitle(BookTitle);
	      n.setBookprice(BookPrice);
	      System.out.println("Book Details");
	      System.out.println("BOOK TITLE--"+n.getBooktitle());
	      System.out.println("BOOK PRICE--"+n.getBookprice());
	      
	     
		 

	}



}
