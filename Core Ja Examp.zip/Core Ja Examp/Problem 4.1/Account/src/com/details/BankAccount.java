package com.details;

public class BankAccount {
   int Accountnum;
   String Accountname;
   String Accounttype ;
   double Accountbalance;
   
	
	public int getAccountnum() {
	return Accountnum;
}

public void setAccountnum(int accountnum) {
	Accountnum = accountnum;
}

public String getAccountname() {
	return Accountname;
}

public void setAccountname(String accountname) {
	Accountname = accountname;
}

public String getAccounttype() {
	return Accounttype;
}

public void setAccounttype(String accounttype) {
	Accounttype = accounttype;
}

public double getAccountbalance() {
	
	if(Accountbalance<10)
	{
		try
		{
			throw new NumberFormatException();
		}
	    catch(NumberFormatException e)
	    {
	    	System.out.println("Account balance is low "+ Accountbalance);
	    }
	     
	}
	return Accountbalance;
}

public void setAccountbalance(double accountbalance) {
	this.Accountbalance = accountbalance;
}

public BankAccount() {
	this.Accountnum = 1001;
	this.Accountname = "ishu";
	this.Accounttype = "Savings";
	this.Accountbalance = 200000;
	System.out.println(this.Accountnum);
    System.out.println(this.Accountname);
    System.out.println(this.Accounttype);
     System.out.println(this.Accountbalance);


}
public BankAccount(int Accountnum,String Accountname,String Accounttype,double Accountbalance) {
	this.Accountnum = Accountnum;
	this.Accountname = Accountname;
	this.Accounttype = Accounttype;
	this.Accountbalance = Accountbalance;


}

void deposit(double amount) {
	if(amount<0){
		try {
			throw new NumberFormatException();
		}
	
	   catch(NumberFormatException ed){
		   
		   System.out.println("Negative amount cannot be deposited");
	   }
	}
		else
		{
			Accountbalance = getAccountbalance() + amount;
		    System.out.println("Current balance is ---"+Accountbalance);
		}
	
	}
public void withdraw(double amount) {
	if(amount>1000){
		try {
			throw new NumberFormatException();
		}
	
	   catch(NumberFormatException ed){
		   
		   System.out.println("we cant deposite amount insufficient balance");
	   }
	}
		else
		{
			Accountbalance = getAccountbalance() - amount;
		    System.out.println("Current balance is ---"+Accountbalance);
		}
	
}
void display()
{
	System.out.println("Balance is ---"+getAccountbalance());
   
    }
	public static void main(String[] args) {
		BankAccount b = new BankAccount();
		
		
		b.deposit(120000);
		b.display();
		b.withdraw(2000);
		b.display();
		b.withdraw(400);
		b.getAccountbalance();
		b.display();
		b.deposit(30);
		b.display();
	}

}
