import java.util.Scanner;

public class PhoneBook {

	public static String help_msg = "press -A Add contact -s Search -Q Exit ";
	public static void main(String[] args) {
		System.out.println(" --------Welcome to my phonebook------");
		Scanner g = new Scanner(System.in);
		for(;;) {
			System.out.println("[main menu]"+help_msg+"\n:");
			String c = g.nextLine().trim();
			
			if (c.equalsIgnoreCase("A")) {
				System.out.println("contact details-name,lastname,phone");
			}
			else if(c.equalsIgnoreCase("s")) {
				System.out.println("Type in the name u r serching\n");
			}
			else if (c.equalsIgnoreCase("Q")) {
				System.out.println("Bye user");
			    System.exit(0);
			 
			}
			else {
				System.out.println("unknown command ");
			}
		
		}

	}

}
