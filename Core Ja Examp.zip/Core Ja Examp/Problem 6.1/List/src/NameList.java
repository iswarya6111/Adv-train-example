import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class NameList {

	public static void main(String[] args) {
		ArrayList<String> d = new ArrayList<String>();
		
		int g ; 
		Scanner h = new Scanner(System.in);
		System.out.println("Enter the number of Students");
		g=h.nextInt();
		System.out.println("Enter the Student name--");
		
		for( int i=0;i<g;i++) {
			d.add(h.next());
			
		}

	System.out.println("Student list");
	
	for (String w :d) {
		System.out.println("search the student name ");
		String f = h.next();
		int position = Collections.binarySearch(d, f);
		System.out.println("position of"+f+"is -- "+position);
	}
	
	
	}

}
