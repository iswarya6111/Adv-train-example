import java.util.Hashtable;
import java.util.Scanner;

public class Product {

	
	public static void main(String args[]) {
		Scanner d = new Scanner (System.in);
		Hashtable<String , String> h = new Hashtable<String , String>();
		System.out.println("Enter the product id and name--");
		
		for(int i=0;i<=3;i++) {
			h.put(d.next(), d.next());
		}
		System.out.println("The product list --");
		System.out.println(h);
		System.out.println("Enter the removal product--");
		String id = d.next();
		h.remove(id);
		System.out.println("item removed");
		System.out.println("the product list is --");
		System.out.println(h.toString());
		System.out.println("Enter the product id to be searched--");
		
		String sid = d.next();
		if(h.containsKey(sid)) {
			System.out.println(h.get(sid));
		}
		else {
			System.out.println("-----Do not exit here ----");
		}
	
	}
}
