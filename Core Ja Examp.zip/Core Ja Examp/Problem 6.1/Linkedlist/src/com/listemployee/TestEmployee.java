package com.listemployee;

import java.util.Vector;

public class TestEmployee {

	private static final Employee[] b = null;
	public static void main(String args[]) {
		Vector<Employee> b = addInput();
		display(b);
	}

     private static Vector <Employee>addInput() {
	 return null;
     }
      private static void display(Vector<Employee> b) {
    	  
      }
     public static Vector <Employee> main1(){
    	 Employee e1 = new Employee(100,"sihu","ishu");
    	 Employee e2 = new Employee(101,"nihi","hini");
    	 Employee e3 = new Employee(102,"niga","gani");
    	 
         Vector <Employee> b = new Vector<Employee>();
         b.add(e1);
         b.add(e2);
         b.add(e3);
        
         
         return b ; 
         
         
     
     }
     public static void main2(String args[]) {
    	 for(Employee e:b) {
    		 System.out.println(e.getEmpid()+"\t"+e.getEmpname()+"\t"+e.getAddress());
    		 
    	 }
     }
}
