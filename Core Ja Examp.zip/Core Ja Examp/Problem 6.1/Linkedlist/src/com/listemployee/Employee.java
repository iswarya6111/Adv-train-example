package com.listemployee;

public class Employee {

	private int empid;
	private String empname;
	private String address;
	
	
	public int getEmpid() {
		return empid;
	}
	public Employee(int empid, String empname, String address) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.address = address;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
