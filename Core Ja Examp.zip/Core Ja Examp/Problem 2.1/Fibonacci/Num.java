
public class Num {

	public static void main(String[] args) {
		int i, count = 13, n = 1 , n1= 3;
		System.out.println("Fibonacci numbers --"+count);
		
		for(i=1 ;i<=count;++i) {
			System.out.println(n+"");
			
			int di = n +n1;
			n = n1;
			n1 = di;
			
		}

	}

}
