import java.util.Scanner;

public class StringVa {
   
	public static void main(String[] args) {
		String str , val = "";
		Scanner s = new Scanner (System.in);
		System.out.println("String value--");
		str = s.nextLine();
		int length = str.length();
		
		for(int i = length-1 ; i>=0; i--)
			val= val +str.charAt(i);
		if (str.equals(val))
			System.out.println(str +"is a palindrome");
		else {
			System.out.println(str +"is not a palindrome");
		}
	}

}

