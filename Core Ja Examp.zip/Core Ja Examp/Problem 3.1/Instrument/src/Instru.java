
abstract class Instru {
	public abstract void play();

}

class Piano extends Instru {
	@Override public void play() {
		System.out.println("Piano is playing tan tan tan");
	}
}
class Flute extends Instru{
	@Override public void play() {
		System.out.println("Flute is playing toot toot toot");
	}
}

class Guitar extends Instru{
	@Override public void play() {
		System.out.println("Guitar is playing tin tin tin");
	}
}
class Instrumental{
	public static void main(String args[]) {
	 Instru I[] = new Instru[10];
	 for (int i = 0;i<10;i++)
	 {
		 switch (i%3) {
		 case 0:{
			 I[i]=new Piano();
			 break;
		 }
		 case 1:{
			 I[i]=new Flute();
			 break;
		 }
		 case 2:{
			 I[i]=new Guitar();
			 break;
		 }
		
		 
		 }
		}
	 
	
	
	for (int i = 0;i<10;i++) {
		System.out.println("Instruments -----"+(i+1));
	    I[i].play();
	      if (I[i] instanceof Piano) {
	    	  System.out.println("Piano");
	      }
	      if (I[i] instanceof Flute) {
	    	  System.out.println("Flute");
	      }
	      if (I[i] instanceof Guitar) {
	    	  System.out.println("Guitar");
	      }
	
	
	
	
	
	}
	}
}