package com.medi;
public class Medicines {

	public void display() {
		System.out.println("Company--Apple Pharmacy");
	   System.out.println("Address--Chennai");
	}
}
class Tablet extends Medicines{
	public void display() {
		System.out.println("Store in a cool temperature");
	}
}
class Syrup extends Medicines{
	public void display() {
		System.out.println("consuption of doctor recomended only");
	}
}
class Ointment extends Medicines{
	public void display() {
		System.out.println("for external use only");
	}
}

