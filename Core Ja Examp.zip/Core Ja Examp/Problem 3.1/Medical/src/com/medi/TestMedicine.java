package com.medi;
public class TestMedicine {

	public static void main(String args[]) {
		Medicines m[] = new Medicines[10];
		double d = Math.random()*2;
		int j = (int) d;
		System.out.println(j);
		switch(j){
		case 1:
			m[0] = new Medicines();
			m[1] = new Tablet();
			m[1].display();
			m[0].display();
			break;
		case 2:
			m[2] = new Medicines();
			m[3] = new Syrup();
			m[3].display();
			m[2].display();
			break;
			
		case 3:
			m[4] = new Medicines();
			m[5] = new Ointment();
			m[5].display();
			m[4].display();
			break;
			
		default: System.out.println("Invalid choice");	
			
			
			
			
			
			
			
			
			
		}
	}
	
	
	
	
}
