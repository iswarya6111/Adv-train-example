
public class StringRot {

	public static void printRotatedString(String s) {
		int len = s.length();
		StringBuffer sb;
		for (int i = 0 ; i< len;i++) {
			sb = new StringBuffer();
			
			int j = i;
			int k = 0;
			
		for(int k2 = j;k2 < s.length();k2++) {
			sb.insert(k, s.charAt(j));
			k++;
			j++;
		}
			j=0;
			while(j<i)
			{
				sb.insert(k, s.charAt(j));
				j++;
				k++;
			}
			System.out.println(sb);
		}
	}
	public static void main(String args[]) {
		String s = new String ("MPHASIS");
		printRotatedString(s);
	}
}
