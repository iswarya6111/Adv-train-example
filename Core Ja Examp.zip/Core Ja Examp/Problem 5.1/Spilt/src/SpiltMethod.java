
public class SpiltMethod {
	public static void main(String args[]) {

	String te = ("23 + 45 - ( 343  / 12 )" );
	String[] d = te.split("\\s");
	
	for (String s:d)
	{
		System.out.println(s);
	}
	
}
}