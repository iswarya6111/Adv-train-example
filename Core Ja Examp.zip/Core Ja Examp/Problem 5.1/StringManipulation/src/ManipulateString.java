
public class ManipulateString {

	public static void main(String[] args) {
		String hi = "JAVA is Simple";
		System.out.println(hi.toUpperCase());
		System.out.println(hi.toLowerCase());
		System.out.println(hi.length());

		
		String[] fi = hi.split("\\s");
		for(String h:fi) {
			System.out.println(h.charAt(0));
			System.out.println("");
		}
           System.out.println("");
	
	String[] fii = hi.split("\\s");
	    for (String h:fii) {
	    	System.out.println(h);
	    }
	
	    StringBuilder g = new StringBuilder("JAVA is Simple");
	   
	    System.out.println("String ="+g.toString());
	    StringBuilder reversehi = g.reverse();
	    System.out.println("Reverse String="+reversehi.toString());
	    
	    System.out.println("length of String "+hi.length());
	
	
	}

}
